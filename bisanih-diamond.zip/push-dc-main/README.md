# push-level-discord Intsal di Termux Android
```
pkg install git
```
```
git clone https://github.com/bangpateng/push-dc
```
```
pkg install python
```
```
apt upgrade && update
```
```
pkg install openssl
```
```
pip install requests colorama
```
```
cd push-dc
```
```
python main.py
```
Created : bgpateng
